package egovframework.kongamItem.emp.controller;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

import javax.annotation.Resource;
import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import egovframework.kongamItem.emp.service.IEmpService;
import egovframework.kongamItem.emp.vo.EmpVO;

@Controller
public class homeController {

	private static final Logger logger = LoggerFactory.getLogger(homeController.class);

	@Resource(name = "empService")
	private IEmpService empService;
	
	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = "/home", method = RequestMethod.GET)
	public String home(Locale locale, Model model , HttpServletRequest req) {
		logger.info("Welcome home! The client locale is {}.", locale);
		
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		
		String formattedDate = dateFormat.format(date);
		
		HttpSession session = req.getSession();
		EmpVO emp = (EmpVO) session.getAttribute("emp");
	
		model.addAttribute("emp",emp);
		model.addAttribute("serverTime", formattedDate );
		
		return "home";
	}
	
	
//	@GetMapping("/loginForm.do")
	@RequestMapping(value = "/loginForm.do", method = RequestMethod.GET)
	public String loginFrm() {
		return "login";
	}

//	@PostMapping("/login.do")
	@RequestMapping(value = "/login.do", method = RequestMethod.POST)
	public String login(RedirectAttributes rttr, HttpServletRequest req, EmpVO emp) {
		EmpVO vo = empService.empCheck(emp.getEmpNo());
		if (vo == null) {
			rttr.addFlashAttribute("msg", "해당 사원번호를 찾을수 없습니다.");
			return "redirect:/loginForm.do";
		} else {
			if (vo.getEmpPw().equals(emp.getEmpPw())) {
				HttpSession session = req.getSession();
				session.setAttribute("emp", vo);
				rttr.addFlashAttribute("msg", "로그인 성공");
				return "redirect:/emp/empList.do";
			}else {
				rttr.addFlashAttribute("msg", "비밀번호가 틀렸습니다.");
				return "redirect:/loginForm.do";
			}
		}

	}
}
