package egovframework.kongamItem.emp.service.Impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import egovframework.kongamItem.emp.service.IEmpService;
import egovframework.kongamItem.emp.vo.EmpVO;
import egovframework.kongamItem.mapper.EmpMapper;
import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

@Service("empService")
public class EmpServiceImpl extends EgovAbstractServiceImpl implements IEmpService {
	
	@Resource(name = "empMapper")
	private EmpMapper empMapper;

	@Override
	public EmpVO empCheck(String empNo) {
		return empMapper.empCheck(empNo);
	}

	@Override
	public void insertEmp(EmpVO emp) {
		empMapper.insertEmp(emp);
		
	}

	@Override
	public List<EmpVO> selectEmpList() {
		return empMapper.selectEmpList();
	}


}
