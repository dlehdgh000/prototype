package egovframework.kongamItem.emp.vo;

import java.util.Date;

import lombok.Data;
import lombok.Getter;

@Data
@Getter
public class EmpVO {
	
	private String empNo; //사원번호
	private String empNm; //사원이름
	private String empEmail;  //사원이메일
	private String empTelNo;  //사원전화번호
	private String empOfcpos;  //사원직위
	private String empMainTelno;  //사원대표번호
	private String empBirdt; //사원생년월일
	private String empEntcomDate;  //사원입사일
	private String jbclsCd;  //직종코드
	private String jobgrpCd;  //직군코드
	private String adptDstCd;  //채용구분코드
	private String empDstCd;  //사원구분코드
	private String salDstCd;  //급여구분코드
	private String genderCd;  //성별코드
	private String statCd;  //상태코드
	private String disabYn;  //장애여부
	private String vetYn; //보훈여부
	private String deptCd;  //부서코드
	private String rcmdText;  //추천내용
	private Date   retDate;  //퇴직일
	private String retRsn;  //퇴직사유
	private String empPw;  //사원비밀번호
	private String empPhoto;  //사원사진
	
	
	
	

}
