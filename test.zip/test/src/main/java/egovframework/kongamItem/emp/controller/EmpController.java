package egovframework.kongamItem.emp.controller;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import egovframework.kongamItem.emp.service.IEmpService;
import egovframework.kongamItem.emp.vo.EmpVO;

@Controller
@RequestMapping("emp")
public class EmpController {

	@Resource(name = "empService")
	private IEmpService empService;

//	@GetMapping("/insertEmpForm.do")
	@RequestMapping(value = "/insertEmpForm.do", method = RequestMethod.GET)
	public String insertEmpForm(HttpServletRequest req, EmpVO emp) {
		return "emp/empForm";
	}
	
	@RequestMapping(value = "/insertEmp.do", method = RequestMethod.POST)
	public String insertEmp(EmpVO emp) {
		empService.insertEmp(emp);
		return "redirect:/";
	}
	
//	@GetMapping("/empList.do")
	@RequestMapping(value = "/empList.do", method = RequestMethod.GET)
	public String empList(Model model) {
		List<EmpVO> emp=  empService.selectEmpList();
		model.addAttribute("emp",emp);
		return "emp/empList";
	}
	
//	@GetMapping("/detail/{empNo}.do")
	@RequestMapping(value = "/detail/{empNo}.do", method = RequestMethod.POST)
	public String empDetail(@PathVariable("empNo") String empNo, Model model) {
		return "emp/emdDetail";
	}
}
