package egovframework.kongamItem.emp.service;

import java.util.List;

import egovframework.kongamItem.emp.vo.EmpVO;

public interface IEmpService {

	EmpVO empCheck(String empNo);

	void insertEmp(EmpVO emp);

	List<EmpVO> selectEmpList();

}
