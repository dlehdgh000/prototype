package egovframework.kongamItem.use.service.Impl;

import egovframework.kongamItem.use.service.UseService;
import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

public class UseServiceImpl extends EgovAbstractServiceImpl implements UseService{

}
