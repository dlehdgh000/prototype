package egovframework.kongamItem.use.vo;

import java.sql.Timestamp;

import lombok.Data;

@Data
public class UseVO {

	private String empNo;
	private String resourceNM;
	private String resourceUse;
	private Timestamp useBeginDate;
	private Timestamp useEndDate;
	private int moveDist;
	private String pssgNm;
	private String progStat;
	
}
