package egovframework.kongamItem.use.service;

public interface UseService {

}
