package egovframework.kongamItem.mapper;

import java.util.List;

import egovframework.rte.psl.dataaccess.mapper.Mapper;

import egovframework.kongamItem.emp.vo.EmpVO;

@Mapper("empMapper")
public interface EmpMapper {
	
	EmpVO empCheck(String empNo);

	void insertEmp(EmpVO emp);

	List<EmpVO> selectEmpList();


}
