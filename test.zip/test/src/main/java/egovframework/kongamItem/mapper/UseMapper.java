package egovframework.kongamItem.mapper;

import egovframework.rte.psl.dataaccess.mapper.Mapper;

@Mapper("useMapper")
public class UseMapper {

}
