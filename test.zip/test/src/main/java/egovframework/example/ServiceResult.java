package egovframework.example;

public enum ServiceResult {
	OK, FAILED, EXIST, NOTEXIST

}
